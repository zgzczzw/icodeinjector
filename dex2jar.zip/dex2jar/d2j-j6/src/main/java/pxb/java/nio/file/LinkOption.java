package pxb.java.nio.file;

public interface LinkOption {
}
